rm -r /usr/local/lib/losu
rm /usr/local/bin/losu
rm /usr/local/bin/losuc
echo "洛书汉语编程语言  已卸载"